const REQUIRED_ENV = "CADASTRO_WEBHOOK_URL";

function json(res, status, payload) {
  res.status(status).setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  return res.end(JSON.stringify(payload));
}

function text(value, maxLength = 500) {
  return String(value ?? "").trim().slice(0, maxLength);
}

function digits(value, maxLength) {
  return String(value ?? "").replace(/\D/g, "").slice(0, maxLength);
}

function validPayload(body) {
  const empresa = body?.empresa;
  const endereco = body?.endereco;
  const administradora = body?.administradora;

  return Boolean(
    empresa?.cnpj?.length === 14 &&
    text(empresa?.razaoSocial) &&
    text(empresa?.nomeFantasia) &&
    text(empresa?.naturezaJuridica) &&
    text(empresa?.dataConstituicao) &&
    endereco?.cep?.length === 8 &&
    text(endereco?.logradouro) &&
    text(endereco?.numero) &&
    text(endereco?.bairro) &&
    text(endereco?.cidade) &&
    text(endereco?.uf).length === 2 &&
    administradora?.cpf?.length === 11 &&
    text(administradora?.nome) &&
    administradora?.whatsapp?.length >= 10 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text(administradora?.email)) &&
    body?.consentimento === true
  );
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return json(res, 405, { message: "Método não permitido." });
  }

  // Endpoint fornecido para a etapa de testes no n8n.
  // Em produção, a variável CADASTRO_WEBHOOK_URL tem prioridade.
  const TEST_WEBHOOK_URL =
    "https://n8n.forteia.com.br/webhook-test/precadastro";

  const webhookUrl = process.env[REQUIRED_ENV] || TEST_WEBHOOK_URL;

  const body = typeof req.body === "string" ? JSON.parse(req.body) : req.body;

  // Honeypot: bots costumam preencher este campo invisível.
  if (text(body?.website)) {
    return json(res, 200, {
      ok: true,
      protocolo: text(body?.protocolo) || "RECEBIDO"
    });
  }

  const clean = {
    protocolo: text(body?.protocolo, 80),
    origem: text(body?.origem, 120),
    enviadoEm: text(body?.enviadoEm, 60),
    perfil: "PROPRIETARIA_ADMINISTRADORA",
    empresa: {
      cnpj: digits(body?.empresa?.cnpj, 14),
      razaoSocial: text(body?.empresa?.razaoSocial, 180),
      nomeFantasia: text(body?.empresa?.nomeFantasia, 180),
      naturezaJuridica: text(body?.empresa?.naturezaJuridica, 180),
      dataConstituicao: text(body?.empresa?.dataConstituicao, 20)
    },
    endereco: {
      cep: digits(body?.endereco?.cep, 8),
      logradouro: text(body?.endereco?.logradouro, 180),
      numero: text(body?.endereco?.numero, 30),
      complemento: text(body?.endereco?.complemento, 120),
      bairro: text(body?.endereco?.bairro, 120),
      cidade: text(body?.endereco?.cidade, 120),
      uf: text(body?.endereco?.uf, 2).toUpperCase()
    },
    administradora: {
      nome: text(body?.administradora?.nome, 180),
      cpf: digits(body?.administradora?.cpf, 11),
      whatsapp: digits(body?.administradora?.whatsapp, 13),
      email: text(body?.administradora?.email, 180).toLowerCase()
    },
    consentimento: body?.consentimento === true,
    metadata: {
      ip: text(
        req.headers["x-forwarded-for"]?.split(",")[0] ||
        req.socket?.remoteAddress ||
        "",
        80
      ),
      userAgent: text(req.headers["user-agent"], 300),
      recebidoEm: new Date().toISOString()
    }
  };

  if (!validPayload(clean)) {
    return json(res, 400, {
      message: "Revise os campos obrigatórios e tente novamente."
    });
  }

  try {
    const webhookResponse = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Jornada-Source": "cadastro-web"
      },
      body: JSON.stringify(clean)
    });

    if (!webhookResponse.ok) {
      const detail = await webhookResponse.text().catch(() => "");
      console.error("Falha no webhook:", webhookResponse.status, detail);
      return json(res, 502, {
        message: "O cadastro não pôde ser registrado agora. Tente novamente."
      });
    }

    return json(res, 200, {
      ok: true,
      protocolo: clean.protocolo
    });
  } catch (error) {
    console.error("Erro ao encaminhar cadastro:", error);
    return json(res, 502, {
      message: "O cadastro não pôde ser registrado agora. Tente novamente."
    });
  }
}
